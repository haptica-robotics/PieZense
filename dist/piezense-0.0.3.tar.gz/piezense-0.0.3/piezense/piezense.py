#!/usr/bin/env python3

import asyncio
import bleak

class PieZense:
    """
    A class for controlling a collection of PieZense pneumatic systems
    """
    def __init__(self):
        self.systems = []
        self.reconnect_task = None
    class _System:
        """
        A class representing a single PieZense system, used internally by the PieZense library
        """
        def __init__(self, system_name: str, channel_count: int):
            self.system_name = system_name
            self.channel_count = channel_count
            self.client = None
    def addSystem(self, system_name: str, channel_count: int) -> int:
        """ 
        register a PieZense system that you want to connect to

        Args:
            system_name (str): Bluetooth name of the PieZense system
            channel_count (int): Number of channels in the system, in the future this second argument may become optional
        """
        return self._addSystem(system_name, channel_count)
    def _addSystem(self, system_name, channel_count) -> int:
        self.systems.append(self._System(system_name, channel_count))
        return len(self.systems) - 1
    def connect(self):
        """
        start the process of connecting to all registered systems
        call this function just once
        use isEverythingConnected() to tell when all registered systems have become connected
        """
        self.reconnect_task = asyncio.run(self._connect())
    async def _connect(self):
        while(True):
            for i, system in enumerate(self.systems):
                if not system.client or not system.client.is_connected: # never connected or disconnected
                    print(f"Need device: {system.system_name}")
                    device = await bleak.BleakScanner.find_device_by_name(system.system_name)
                    print(f"Scanned for device: {system.system_name}")
                    if device:
                        print(f"Found device: {device}")
                        system.client = bleak.BleakClient(device)
                        await system.client.connect()
                        if system.client.is_connected:
                            system.is_connected = True
                            print(f"Connected to device: {system.system_name}")
                            services=system.client.services
                            print(f"Services: {services}")
                        else:
                            print(f"Failed to connect to device: {system.system_name}")
                            system.client = None
                await asyncio.sleep(10)

    def isEverythingConnected(self):
        pass
    def sendConfig(self, system_num: int, channel_num: int, config_data: dict):
        pass

# """This module provides the PieZense class for interfacing with PieZense pneumatic systems via Bluetooth Low Energy (BLE)."""
# class PieZense:
#     def __init__(self):
#         self.system_client_list=[] # list of BleakClient objects
    
#     """Connect to multiple PieZense systems by their names."""
#     def connect_to_systems(self, system_name_list_input):
#         self.system_name_list = system_name_list_input
#         self.num_systems = len(self.system_name_list)
#         for i, _ in enumerate(self.system_name_list):
#             self.system_client_list.append(None)

#         asyncio.run(self.reconnect_to_systems())

#     async def reconnect_to_systems(self):
#         while(True):
#             for i, system_name in enumerate(self.system_name_list):
#                 if self.system_client_list[i] is None: # connect
#                     print(f"Need device: {system_name}")
#                     device = await bleak.BleakScanner.find_device_by_name(system_name)
#                     print(f"Scanned for device: {system_name}")
#                     if device:
#                         print(f"Found device: {device}")
#                         self.system_client_list[i] = bleak.BleakClient(device)
#                         # self.system_client_list[i].set_disconnected_callback(self.generate_disconnect_callback(i, system_name))
#                         await self.system_client_list[i].connect()
#                         if self.system_client_list[i].is_connected:
#                             print(f"Connected to device: {system_name}")
#                             services=await self.system_client_list[i].services
#                             print(f"Services: {services}")

#                             for service in services:
#                                 for char in service.characteristics:
#                                     if "notify" in char.properties:
#                                         print(f"[{system_name}] Subscribing to {char.uuid}")
#                                         await self.system_client_list[i].start_notify(
#                                             char.uuid,
#                                             lambda sender, data, idx=i: self.notification_handler(idx, sender, data)
#                                         )
#                         else:
#                             print(f"Failed to connect to device: {system_name}")
#                             self.system_client_list[i] = None

#                 else:
#                     print(f"Device not found, will retry: {system_name}")
#                 await asyncio.sleep(11)

#     def notification_handler(self, device_index, sender, data):
#         expected_without_ts = FOLLOWER_COUNT * 2
#         pressure_data = data[:expected_without_ts]
#         num_followers = len(pressure_data) // 2 # // does integer division
#         for follower_id in range(num_followers):
#             low_byte = pressure_data[follower_id * 2]
#             high_byte = pressure_data[follower_id * 2 + 1]
#             pressure_value = (high_byte << 8) | low_byte
#             print(f"Device {device_index}, Follower {follower_id}, Pressure: {pressure_value} Pa")

            