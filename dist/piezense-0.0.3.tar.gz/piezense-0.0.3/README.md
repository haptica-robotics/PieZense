# PieZense
a python library for Haptica Robotics' pneumatic system

## Example programs
https://github.com/haptica-robotics/piezense-examples

