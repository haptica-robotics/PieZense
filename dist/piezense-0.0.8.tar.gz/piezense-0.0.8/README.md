# PieZense
a python library for Haptica Robotics' pneumatic system

## Example programs
https://github.com/haptica-robotics/piezense-examples




## notes for developers

python3 setup.py sdist bdist_wheel

twine upload --repository pypi dist/*

